package examen_2;

public enum Departamento {
	Informatica, Gestion, Marketing 
}
