package examen_2;

public class DNIException extends Exception{
	private static final long serialVersionUID = 1L;
}
