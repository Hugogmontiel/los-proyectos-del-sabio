import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Date;
public class CuentaBancaria {

	
	private String IBAN;
	private String titular;
	private Double saldo;
	private Date fechaCreacion;
	private int numMaxMovimientos = 100;
	
	private Movimiento[] coleccion;
	
	private int numActualesMovimientos = 0;
	
	
	
	
	
	public CuentaBancaria(String IBAN, String titular, Double saldo, Date fechaCreacion) {
		
	this.IBAN = IBAN;
	this.titular = titular;
	this.saldo = saldo;
	this.fechaCreacion = fechaCreacion;
	this.coleccion = new Movimiento[this.numMaxMovimientos];
	
	}
	
	public CuentaBancaria(String IBAN, String titular, Double saldo, int movimientos) {
		
	this.IBAN = IBAN;
	this.titular = titular;
	this.saldo = 0.00;
	this.numActualesMovimientos = 0;
	
	}

	public String getIBAN() {
		return IBAN;
	}

	private boolean setIBAN(String IBAN) {
		this.IBAN = IBAN;
		return true;
		/*
		boolean isOk = this.isbnValidator(IBAN);
		if(isOk)
		{
			this.IBAN = IBAN;
		}
		else {
			System.out.println("Formato incorrecto");
		}
		
		return isOk;*/
	}
	
	private boolean IBANValidator(String IBAN) {
		
		boolean isFormatOk = false;
		String regex = "[A-Z] {2}\\d{22}$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(IBAN);
		if(matcher.matches()) {
			this.IBAN = IBAN;
			isFormatOk = true;
		
		}
		
		return isFormatOk;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public Double getSaldo() {
		return saldo;
	}
	
	private boolean setSaldo(Double saldo) {
		this.saldo = saldo;
		return true;
	}

	private boolean saldoValidator(Double saldo) {
		boolean isFormatOk = false;
		if (saldo < -50.00 || saldo > 3000.00) {
			isFormatOk = false;
			
		}
		else {
			this.saldo = saldo;
			isFormatOk = true;
			
		}
		
		return isFormatOk;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	
	
	
	
	
}
